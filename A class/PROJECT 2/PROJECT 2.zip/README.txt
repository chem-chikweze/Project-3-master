Chukwubuikem Chikweze
31531764

1. How to build:

    stack.c contains the main method.
        --> type: "gcc -Wall -Werror stack.c -o a"
        --> Press enter
2. How to run
    --> type: ".\a"

Had a major flaw correctly printing the trees.
