Chukwubuikem Chikweze
31531764

1. How to build:

    a.c contains the main method.
        --> type: "gcc -Wall -Werror a.c -o a"
        --> Press enter
2. How to run
    --> type: ".\a"

Used AVL Tree to build the set for the NFA. 
In function 'run()", I reused one DFA for each of the 5 DFAs and one NFA for each of the 4 NFAs thus adding up to 9.